#ifndef P1_PROTOTYPE_MEMORY_H
#define P1_PROTOTYPE_MEMORY_H

#endif //P1_PROTOTYPE_MEMORY_H

void * allocate_memory_dynamically(int, const void *);